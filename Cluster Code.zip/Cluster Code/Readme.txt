In order to launch job
1) Run "Precompute_SF_Matrix_Lambda.py" in order to precompute the the constant part of the FS matrix
2) Modify "array.sbatch", specificaly replace [Name of environnement] by name of conda environnement
3) Launch job: sbatch --array=0-999 array.sbatch

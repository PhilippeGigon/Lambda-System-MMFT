import numpy as np
import scipy as sp
import math as math
from qutip import *
import pickle
# Contains the perturbation theory
from ShirleyFloquet import *
###############################################################
# Parallelized parameter sweepe
###############################################################
"""
This function sweepes the drive frequencies in the case 
of two different drives. omegad1, omegad2 are the respective
drive frequencies. IndicesOrdern are the indices of the reduced
submatrix, Collisionindex_Reduced is the index of the band in the
reduced space, Hcst is the part of the Hamiltonian which does not
depend on the drive frequencies, Ncut the cutoff of the Fourier modes,
order the order in perturbation theory and treshold the value at which 
we consider that two levels are colliding. This code is written to be
executed on a cluster. To do this one first needs to compute the constant
part of the  Hamiltonian and the relevant in the seperate file: 
Precompute_SF_Matrix_Lambda.py
"""

#############################################
# Cluster parameters
#############################################
Npoints = 1000  # To Launch use sbatch --array=0-999 array.sbatch
indexsimul = int(sys.argv[1])  # Index of current simulation

#############################################
# Physical parameters
#############################################
order = 3  # Order in perturbation theory up to which we look for collisions
Ncut = 2*order  # Ncut >> 3k/2, where k is the order we want to reach
dimFourier = 2*Ncut+1
treshold = 0.01  # Treshold for level indentification
factinf = 0.5 # Range for param sweepe
factmax = 1.8
Eg = 1
Ee = 2
Ef = 3
H0 = np.diag([Eg, Ee, Ef])
dimSpace = len(H0)
delta = 0 #Detuning
omegad1range = np.linspace(factinf*(Ef-Eg), factmax*(Ef-Eg), Npoints)
omegad1 = omegad1range[indexsimul] # Cf report for form of drive
omegad2 = omegad1-(Ee-Eg)-delta # Cf report for form of drive

# This loads the precomputed constant part of the HFS matrix as well as the indices
# of the relevant subspace
name = "PrecomputedHcst_delta=0_epsilon=0.1"
with open(name + '.pickle', 'rb') as inp:
    result = pickle.load(inp)
Hcstsub = result["Hcstsub"]
IndicesOrdern = result["IndicesOrdern"]
Collisionindex_Reduced = result["Collisionindex_Reduced"]

###############################################################
# Constructing Shirley Floquet matrix
###############################################################
HFS = np.zeros((dimSpace*dimFourier**2, dimSpace*dimFourier**2))
IA = np.eye(dimSpace)
for n, m in product(range(dimFourier), range(dimFourier)):
    n1 = np.zeros(dimFourier)
    n1[n] = 1
    n1 = n1.reshape(1, -1)
    n1mat = np.zeros((dimFourier, dimFourier))
    n1mat[n, n] = 1
    n2mat = np.zeros((dimFourier, dimFourier))
    n2mat[m, m] = 1
    HFS += np.kron(n1mat, np.kron(n2mat, IA)) * \
        (omegad1*(n-Ncut)+omegad2*(m-Ncut))
Hsub = HFS[np.ix_(IndicesOrdern, IndicesOrdern)]+Hcstsub
subspacedim = len(Hsub)

###############################################################
# Compute collision angles using superoperator formalism
###############################################################
collisionangles = np.zeros((order+1, subspacedim))
# Compute all collisions up to given order
for k in range(subspacedim):
    if k != Collisionindex_Reduced:
        index = [Collisionindex_Reduced, k]
        # Add the degenerate states to subspace
        for a in np.diag(Hsub)[index]:
            for jj in np.where(np.diag(Hsub) == a)[0]:
                if jj not in index:
                    index.append(jj)
        Kpure = Hsub[np.ix_(index, index)]
        K = np.diag(np.diag(Hsub))
        K[np.ix_(index, index)] = Kpure
        V = Hsub-K
        G, Hcorrections = Perturbative_corrections(
            np.array(K), np.array(V), int(order))
        for indcor in range(len(Hcorrections)):
            Hcor = np.sum(Hcorrections[:indcor+1], axis=0)
            Subspace = Hcor[np.ix_(index, index)]
            Deltak = Subspace[0, 0]-Subspace[1, 1]  # Effective detuning
            gk = Subspace[1, 0]  # Effective coupling
            if np.abs(Deltak) > 1e-18:
                # Collision angle at order k
                collisionangles[indcor, k] = (np.arctan(np.abs(2*gk/Deltak)))
            if np.abs(Deltak) < 1e-18 and np.abs(gk) > 1e-17:
                collisionangles[indcor, k] = math.pi/2

###############################################################
# Extract data for visualization
###############################################################
spectrange, vect = np.linalg.eigh(Hsub) #Eigenvalues of FS matrix

#Parameters for visualization
Plot_spectrum = np.zeros_like(collisionangles, dtype=bool)
Plot_spectrum_Color = np.zeros_like(collisionangles, dtype=float)
Plot_spectrum_Floquet_Band = np.zeros_like(collisionangles, dtype=int)

# Find all the FLOQUET bands which collide with more than a given treshold angle
for ord_ in range(len(collisionangles[:, 0])):
    collisions = np.where(collisionangles[ord_, :] > treshold)[0]
    for collisionbandindex in collisions:
        kvec = np.zeros(subspacedim)
        kvec[collisionbandindex] = 1
        olaptemp = np.zeros(subspacedim)
        for redfloquetmode in range(subspacedim):
            olaptemp[redfloquetmode] = np.abs(
                np.dot(np.conj(vect[:, redfloquetmode].T), kvec))**2
        # Enable the coloring
        maxind = np.argmax(olaptemp)
        Plot_spectrum[ord_, maxind] = True
        Plot_spectrum_Color[ord_,
                            maxind] = collisionangles[ord_, collisionbandindex]
        Plot_spectrum_Floquet_Band[ord_, maxind] = collisionbandindex
        
#############################################
# Save results using pickle
#############################################
result = {"omegaind": indexsimul, 'collisionangles': collisionangles, 'spectrange': spectrange, 'Plot_spectrum': Plot_spectrum, 'Plot_spectrum_Color': Plot_spectrum_Color,
          'omegad1': omegad1, 'omegad2': omegad2, "Plot_spectrum_Floquet_Band": Plot_spectrum_Floquet_Band}
name = "Output/Lambdasystem_OmegaSweepe_Range_"+str(factinf)+"_"+str(factmax)+"_delta="+str(
    np.round(delta, 3))+"_Simulation="+str(os.environ['SLURM_ARRAY_TASK_ID'])
with open(name+'.pickle', 'wb') as outp:
    pickle.dump(result, outp, pickle.HIGHEST_PROTOCOL)

# Contains the perturbation theory
from ShirleyFloquet import *
import numpy as np
import scipy as sp
import math as math
from matplotlib import cm
from qutip import *
import pickle

################################################
# Physical parameters, see my paper for notations
################################################
order = 3  # Order in perturbation theory
Ncut = 2*order  # Cutoff Fourier modes (Ncut >> 3order/2 cf. report)
dimFourier = 2*Ncut+1  # Number of Fourier modes
treshold = 0.01  # Treshold for level indentification
Eg = 1
Ee = 2
Ef = 3
H0 = np.diag([Eg, Ee, Ef])
dimSpace = len(H0)
epsilond1 = 0.1  # First drive amplitude
epsilond2 = 0.1  # Second drive amplitude
Hd1 = np.array([[0, 0, epsilond1], [0, 0, epsilond1],
               [epsilond1, epsilond1, 0]])  # First drive coupling operator
Hd2 = np.array([[0, 0, epsilond2], [0, 0, epsilond2],
               [epsilond2, epsilond2, 0]])  # Second drive coupling operator

###############################################################
# Construct Floquet Shirley Hamiltonian and extract submatrix
###############################################################
IA = np.eye(dimSpace)  # Identity on the initial space

SFplus = np.diag(np.ones(dimFourier-1), -1)  # Shift operator
SFminus = np.diag(np.ones(dimFourier-1), +1)  # Shift operator
SFzero = np.eye(dimFourier)  # Identity on Fourier space

# This part of the FS matrix does not depend on the drive frequency
Hcst = np.zeros((dimFourier**2*dimSpace, dimFourier**2*dimSpace))
Hcst += np.kron(SFzero, np.kron(SFzero, H0))  # H(0,0)
Hcst += np.kron(SFplus, np.kron(SFzero, Hd1/2))  # H(1,0)
Hcst += np.kron(SFminus, np.kron(SFzero, Hd1/2))  # H(-1,0)
Hcst += np.kron(SFzero, np.kron(SFplus, Hd2/2))  # H(0,1)
Hcst += np.kron(SFzero, np.kron(SFminus, Hd2/2))  # H(0,-1)

# This is the drive frequency dependent part, we only compute it to extract the submatrix
Hphoton = np.zeros_like(Hcst)
# Dummy drive to extract submatrix, with the irrational numbers we make sure there is no degeneracy
omegad1 = 1.5+math.pi/math.e
omegad2 = 1.6+math.pi/33
for n, m in product(range(dimFourier), range(dimFourier)):
    n1 = np.zeros(dimFourier)
    n1[n] = 1
    n1 = n1.reshape(1, -1)
    n1mat = np.zeros((dimFourier, dimFourier))
    n1mat[n, n] = 1
    n2mat = np.zeros((dimFourier, dimFourier))
    n2mat[m, m] = 1
    Hphoton += np.kron(n1mat, np.kron(n2mat, IA)) * \
        (omegad1*(n-Ncut)+omegad2*(m-Ncut))
    
#Example FS matrix
HFS = np.array(Hcst)+np.array(Hphoton)

# Collision index in complete Hamiltonian
Collisionindex_Initial = [np.where(np.diag(HFS) == Eg)[0][0]]

#############################################
# Extract submatrix at order specified before
#############################################
#Get the indices of relevant subspace
IndicesOrdern = get_n_NN_Submatrix_index(
    HFS, Collisionindex_Initial, n=math.floor(3*order/2))  
#Get the relevant submatrix
Hsub = HFS[np.ix_(IndicesOrdern, IndicesOrdern)]
# Collision index in reduced Hamiltonian
Collisionindex_Reduced = np.where(np.diag(Hsub) == Eg)[0][0]  
subspacedim = len(Hsub)

#############################################
# Export results 
#############################################
result = {"Hcstsub": Hcst[np.ix_(IndicesOrdern, IndicesOrdern)],
          "IndicesOrdern": IndicesOrdern, "Collisionindex_Reduced": Collisionindex_Reduced}
name = "PrecomputedHcst"
with open(name+'.pickle', 'wb') as outp:
    pickle.dump(result, outp, pickle.HIGHEST_PROTOCOL)
